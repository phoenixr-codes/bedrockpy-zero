from functools import partial, wraps
import textwrap
from typing import Sequence
from uuid import uuid4

shorten = partial(textwrap.shorten, width = 15)

def uuid() -> str:
    """Generate uuid v4
    
    Returns
    -------
    New random uuid v4 as string.
    """
    return str(uuid4())

def boolean(
    string: str,
    /, *,
    true: Sequence[str] = ("true", "yes"),
    false: Sequence[str] = ("false", "no")
) -> bool:
    """Converts string to boolean.
    
    Note
    ----
    Matching is case insensitive.
    
    Parameters
    ----------
    true
        Strings that indicate ``True``.
    
    false
        Strings that indicate ``False``.
    
    Returns
    -------
    ``True`` if matched one of ``true``,
    ``False`` if matched one of ``false``.
    
    Raises
    ------
    :class:`RuntimeError`
        Invalid parameters are given.
    
    :class:`ValueError`
        Cannot convert value to a boolean.
    """
    for x in true:
        if not isinstance(x, str):
            raise RuntimeError(f"expected 'str', got {x.__class__.__name__!r}")
        
        if x in false:
            raise RuntimeError(f"duplicate ({x!r})")
    
    if string.lower() in (i.lower() for i in true):
        return True
    
    elif string.lower() in (i.lower() for i in false):
        return False
    
    raise ValueError("string cannot be converted to boolean")
