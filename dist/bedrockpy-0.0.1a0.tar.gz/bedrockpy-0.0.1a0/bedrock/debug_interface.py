from inspect import cleandoc
import sys

if sys.version_info[:2] < (3, 8):
    from importlib_metadata import version as metadata_version
else:
    from importlib.metadata import version as metadata_version

from packaging.version import Version
from . import chatstyle as cs

bedrockpy = Version(metadata_version("bedrockpy"))

WELCOME1 = f"{cs.CODE_BUILDER} {cs.bold}{cs.gold}bedrockpy{cs.reset}"

WELCOME2 = cleandoc(f"""
    | {cs.bold("version")} {".".join(map(str, bedrockpy.release))}
    | {cs.bold("release")} {"prerelease" if bedrockpy.is_prerelease else "release"}
    | {cs.red("Debug Mode")}
    |
    | connection @ {cs.yellow}%(host)s:%(port)d{cs.reset}
    |
    | Thanks for using bedrockpy {cs.red("<3")}
    | {cs.aqua("github.com/phoenixr-codes/bedrockpy")}
""")

RECEIVED = cleandoc(f"""
    {cs.bold("[bedrckpy :: debug]")}
    {cs.blue(">")} %(message)s
""")
