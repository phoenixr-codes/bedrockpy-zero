import json
import typing
import warnings

class Context:
    def __init__(self, server: 'Server', **data: dict[str, typing.Any]):
        self._server = server
        self.data = data
    
    async def run(self, command: str) -> None:
        await self._server.command_request(command)
    
    async def tell(self, text, target = "@a"):
        await self.run(f"tell {target} {text}")
    
    async def  tell_raw(self, text, target = "@a"):
        data = json.dumps({
            "rawtext": [{
                "text": text
            }]
        })
        await self.run(f"tellraw {target} {data}")

class Message(Context):
    def __init__(self, server: 'Server', **data: dict[str, typing.Any]):
        super().__init__(server, **data)
        
        # expecting body in data
        self.message = data["message"]
        self.receiver = data["receiver"]
        self.author = data["sender"]
        self.chat_type = data["type"]
    
    async def reply(self, *args, **kwargs):
        await self.tell(
            *args, **kwargs,
            target = self.author,
        )
    
    async def reply_raw(self, *args, **kwargs):
        await self.tell_raw(
            *args, **kwargs,
            target = self.author
        )