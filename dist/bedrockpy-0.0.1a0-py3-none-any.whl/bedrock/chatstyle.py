class Color:
    def __init__(self, color):
        self.color = f"§{color}"
    
    def __str__(self):
        return self.color
    
    def __call__(self, text):
        return f"{self.color}{text}§r"

black = Color("0")
darkblue = Color("1")
darkgreen = Color("2")
darkaqua = Color("3")
darkred = Color("4")
darkpurple = Color("5")
gold = Color("6")
gray = grey = Color("7")
darkgray = darkgrey = Color("8")
blue = Color("9")
green = Color("a")
aqua = Color("b")
red = Color("c")
lightpurple = Color("d")
yellow = Color("e")
white = Color("f")
obfuscated = Color("k")
bold = Color("l")
italic = Color("o")
reset = Color("r")

CODE_BUILDER = "\uE103"
